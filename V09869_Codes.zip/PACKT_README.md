
Mapping of lectures to resources:

04.setting-up-jquery        => jquery-project-template
14.css-selectors            => https://www.w3schools.com/jquery/jquery_ref_selectors.asp
18.adding-elements          => Adding Elements via jQuery.pdf
27.event-handling           => http://api.jquery.com/category/events/
34.event-data               => https://api.jquery.com/event.data/
44.flickr                   => https://www.flickr.com/services/feeds/docs/photos_public/
45.pokeapi                  => https://github.com/toddmotto/public-apis
45.pokeapi                  => http://pokeapi.co/
45.pokeapi                  => https://swapi.co/